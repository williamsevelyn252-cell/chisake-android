# CHISAKE — Android-only Flutter starter

**Product:** CHISAKE  
**Tagline:** Connect. Chat. Share. Belong.  
**Brand colours:** Purple and white only  
**Target:** Android 8.0 (API 26) and newer  
**Application ID:** `com.chisake.social`

## Appwrite project configuration
- Endpoint: `https://fra.cloud.appwrite.io/v1`
- Project ID: `6ae89241000d1a36bd0d`

The endpoint and project ID are client configuration values. Never place an Appwrite API key or server secret inside the Android app.

## Build the Android project

You need a computer with Flutter SDK and Android Studio installed. The ZIP contains the Flutter app source; generate the native Android wrapper by running these commands from this folder:

```bash
flutter create . --platforms=android
```

Then edit `android/app/build.gradle.kts`:
- Set `namespace = "com.chisake.social"`
- Set `applicationId = "com.chisake.social"`
- Set `minSdk = 26`

If your generated project uses Groovy (`build.gradle`) instead, set the equivalent `namespace`, `applicationId`, and `minSdkVersion 26`.

In Appwrite Console:
1. Open the CHISAKE project.
2. Add Platform → Android.
3. Enter package name `com.chisake.social`.
4. Enable Email/Password authentication in Auth settings.

Then run:

```bash
flutter pub get
flutter run
```

To create a release APK:

```bash
flutter build apk --release
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Included in this first foundation
- Android-only Flutter app source (no web target).
- Appwrite Flutter client initialised with the supplied project ID and endpoint.
- Email/password registration and login.
- Session restoration and logout.
- Purple-and-white Facebook-inspired home-feed shell.
- Stories strip, sample feed cards, and bottom navigation.

## Not yet implemented
This is the first foundation, not the completed social network. The current feed cards and navigation items are UI placeholders. Next milestones are:
1. Create Appwrite database and storage buckets with secure permissions.
2. Complete user profile onboarding (date of birth, gender, phone, bio, interests, profile/cover images).
3. Implement real posts, likes, comments, shares, friends and status.
4. Implement private/group messaging, voice notes and realtime delivery.
5. Add push notifications, then LiveKit voice/video calling.
6. Implement settings, privacy, blocking, archiving, saved posts and watched history.

Phone number registration/search requires verified phone numbers and appropriate privacy/consent controls. Voice/video calling and push notifications need additional platform configuration and testing.

## Android compatibility
The app is configured in the build instructions for Android 8.0 (API 26) minimum. Actual compatibility must be verified on Android 8+ devices during testing.
