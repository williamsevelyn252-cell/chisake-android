import 'package:flutter/material.dart';
import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as models;

const projectId = '6ae89241000d1a36bd0d';
const endpoint = 'https://fra.cloud.appwrite.io/v1';

const purple = Color(0xFF6B2DBD);
const deepPurple = Color(0xFF4A148C);
const palePurple = Color(0xFFF3ECFA);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final client = Client()
      .setEndpoint(endpoint)
      .setProject(projectId);
  runApp(ChisakeApp(account: Account(client)));
}

class ChisakeApp extends StatefulWidget {
  const ChisakeApp({super.key, required this.account});
  final Account account;

  @override
  State<ChisakeApp> createState() => _ChisakeAppState();
}

class _ChisakeAppState extends State<ChisakeApp> {
  models.User? user;
  bool checking = true;

  @override
  void initState() {
    super.initState();
    _restoreSession();
  }

  Future<void> _restoreSession() async {
    try {
      user = await widget.account.get();
    } catch (_) {
      user = null;
    }
    if (mounted) setState(() => checking = false);
  }

  void _onAuthenticated(models.User value) {
    setState(() => user = value);
  }

  Future<void> _logout() async {
    try {
      await widget.account.deleteSession(sessionId: 'current');
    } catch (_) {}
    if (mounted) setState(() => user = null);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CHISAKE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          primary: purple,
          secondary: deepPurple,
          surface: Colors.white,
        ),
        scaffoldBackgroundColor: const Color(0xFFFAF8FC),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: deepPurple,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: palePurple,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: checking
          ? const Scaffold(body: Center(child: CircularProgressIndicator(color: purple)))
          : user == null
              ? AuthScreen(account: widget.account, onAuthenticated: _onAuthenticated)
              : HomeScreen(user: user!, onLogout: _logout),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.account, required this.onAuthenticated});
  final Account account;
  final ValueChanged<models.User> onAuthenticated;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool isRegister = true;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    FocusScope.of(context).unfocus();
    setState(() { busy = true; error = null; });
    try {
      if (isRegister) {
        if (name.text.trim().isEmpty) throw Exception('Please enter your full name.');
        await widget.account.create(
          userId: ID.unique(),
          email: email.text.trim(),
          password: password.text,
          name: name.text.trim(),
        );
        await widget.account.createEmailPasswordSession(
          email: email.text.trim(),
          password: password.text,
        );
      } else {
        await widget.account.createEmailPasswordSession(
          email: email.text.trim(),
          password: password.text,
        );
      }
      final current = await widget.account.get();
      if (mounted) widget.onAuthenticated(current);
    } on AppwriteException catch (e) {
      setState(() => error = e.message ?? 'Could not complete your request.');
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    name.dispose(); email.dispose(); password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              color: Colors.white,
              elevation: 1,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const _Brand(),
                  const SizedBox(height: 12),
                  Text(isRegister ? 'Create your account' : 'Welcome back',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: deepPurple)),
                  const SizedBox(height: 6),
                  const Text('Connect. Chat. Share. Belong.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                  const SizedBox(height: 24),
                  if (isRegister) ...[
                    TextField(controller: name, textCapitalization: TextCapitalization.words,
                      decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person_outline))),
                    const SizedBox(height: 12),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email_outlined))),
                  const SizedBox(height: 12),
                  TextField(controller: password, obscureText: true,
                    decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline))),
                  if (error != null) ...[
                    const SizedBox(height: 12),
                    Text(error!, style: const TextStyle(color: deepPurple)),
                  ],
                  const SizedBox(height: 18),
                  FilledButton(
                    onPressed: busy ? null : submit,
                    style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.symmetric(vertical: 16)),
                    child: busy
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Text(isRegister ? 'Create account' : 'Log in'),
                  ),
                  TextButton(
                    onPressed: busy ? null : () => setState(() { isRegister = !isRegister; error = null; }),
                    child: Text(isRegister ? 'Already have an account? Log in' : 'New to CHISAKE? Create an account',
                      style: const TextStyle(color: deepPurple)),
                  ),
                  const SizedBox(height: 4),
                  const Text('Starter build: email/password authentication is enabled first. Phone verification and profile details are the next setup stage.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45)),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.user, required this.onLogout});
  final models.User user;
  final VoidCallback onLogout;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selected = 0;
  final postController = TextEditingController();

  @override
  void dispose() { postController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final tabs = ['Home', 'Friends', 'Reels', 'Messages', 'Notifications', 'Menu'];
    final icons = [Icons.home_filled, Icons.people_alt_outlined, Icons.movie_outlined,
      Icons.chat_bubble_outline, Icons.notifications_none, Icons.menu];
    return Scaffold(
      appBar: AppBar(
        title: const Text('CHISAKE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, color: purple)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.chat_bubble_rounded)),
          IconButton(onPressed: widget.onLogout, tooltip: 'Log out', icon: const Icon(Icons.logout)),
          const SizedBox(width: 6),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: ListView(padding: const EdgeInsets.fromLTRB(14, 10, 14, 24), children: [
            _navRow(tabs, icons),
            const SizedBox(height: 14),
            _stories(),
            const SizedBox(height: 14),
            Card(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: [
                  Row(children: [
                    CircleAvatar(backgroundColor: palePurple, child: Text(_initial(widget.user.name))),
                    const SizedBox(width: 10),
                    Expanded(child: Text('What’s on your mind, ${widget.user.name.split(' ').first}?',
                      style: const TextStyle(color: Colors.black54))),
                  ]),
                  const Divider(height: 22),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: const [
                    _ActionLabel(icon: Icons.image_outlined, label: 'Photo'),
                    _ActionLabel(icon: Icons.videocam_outlined, label: 'Video'),
                    _ActionLabel(icon: Icons.edit_outlined, label: 'Write'),
                  ]),
                ]),
              ),
            ),
            const SizedBox(height: 14),
            _postCard('Welcome to CHISAKE 💜', 'Your community starts here. Connect, chat, share and belong.',
              'CHISAKE Team', Icons.campaign_outlined),
            _postCard('Your profile is ready for its next step', 'Add a profile photo, cover image and a little about yourself as we build out your social space.',
              widget.user.name, Icons.person_outline),
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('This is the connected app foundation. Posts, friends, chat, status, reels and calls will be enabled in the next build stages.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 12)),
            ),
          ]),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (i) {
          setState(() => selected = i);
          if (i != 0) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('${tabs[i]} module is scheduled for the next development stage.')),
            );
          }
        },
        destinations: List.generate(tabs.length, (i) => NavigationDestination(
          icon: Icon(icons[i]), label: tabs[i])),
      ),
    );
  }

  Widget _navRow(List<String> labels, List<IconData> icons) => Card(
    color: Colors.white,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        for (int i = 0; i < 5; i++)
          IconButton(onPressed: () => setState(() => selected = i),
            color: selected == i ? purple : Colors.black54, icon: Icon(icons[i])),
      ]),
    ),
  );

  Widget _stories() => SizedBox(
    height: 116,
    child: ListView(scrollDirection: Axis.horizontal, children: [
      _story('Add to story', Icons.add, isAdd: true),
      _story('Your story', Icons.person_outline),
      _story('Friends', Icons.people_outline),
      _story('Discover', Icons.explore_outlined),
    ]),
  );

  Widget _story(String label, IconData icon, {bool isAdd = false}) => Container(
    width: 92, margin: const EdgeInsets.only(right: 9),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: palePurple)),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      CircleAvatar(backgroundColor: isAdd ? purple : palePurple,
        child: Icon(icon, color: isAdd ? Colors.white : purple)),
      const SizedBox(height: 7),
      Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
    ]),
  );

  Widget _postCard(String title, String body, String author, IconData icon) => Card(
    color: Colors.white,
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(backgroundColor: palePurple, child: Icon(icon, color: purple)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(author, style: const TextStyle(fontWeight: FontWeight.bold)),
            const Text('Just now · CHISAKE', style: TextStyle(fontSize: 11, color: Colors.black45)),
          ])),
          const Icon(Icons.more_horiz),
        ]),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: deepPurple)),
        const SizedBox(height: 6),
        Text(body),
        const Divider(height: 24),
        const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _ActionLabel(icon: Icons.thumb_up_alt_outlined, label: 'Like'),
          _ActionLabel(icon: Icons.mode_comment_outlined, label: 'Comment'),
          _ActionLabel(icon: Icons.share_outlined, label: 'Share'),
        ]),
      ]),
    ),
  );
}

class _Brand extends StatelessWidget {
  const _Brand();
  @override
  Widget build(BuildContext context) => Column(children: [
    Container(width: 76, height: 76,
      decoration: BoxDecoration(color: purple, borderRadius: BorderRadius.circular(25)),
      child: const Center(child: Text('C', style: TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.w900))),
    ),
    const SizedBox(height: 10),
    const Text('CHISAKE', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: purple, letterSpacing: 2)),
  ]);
}

class _ActionLabel extends StatelessWidget {
  const _ActionLabel({required this.icon, required this.label});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(icon, color: purple, size: 19),
    const SizedBox(width: 5),
    Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
  ]);
}

String _initial(String value) => value.trim().isEmpty ? 'C' : value.trim()[0].toUpperCase();
